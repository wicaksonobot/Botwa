const funct = 'Tes Doang'

export default funct